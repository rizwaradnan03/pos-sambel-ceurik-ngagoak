import { TReactNode } from '@/types/html-type'
import React from 'react'

const AppProvider = ({children}: {children: TReactNode}) => {

    return (
        <div>AppProvider</div>
    )
}

export default AppProvider