export const UseJsonStringify = ({data}: {data: any}) => {
    return JSON.stringify(data)
}