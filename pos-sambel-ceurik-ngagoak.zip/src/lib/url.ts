export const UseGetCurrentUrl = () => {
    return location.pathname
}