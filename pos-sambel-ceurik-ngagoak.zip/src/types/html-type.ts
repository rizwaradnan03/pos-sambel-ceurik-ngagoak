import { ElementType } from "react"

export type TReactNode = React.ReactNode

export type TElementType = ElementType