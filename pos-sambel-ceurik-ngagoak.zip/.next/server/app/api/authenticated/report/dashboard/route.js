(()=>{var e={};e.id=4033,e.ids=[4033],e.modules={96330:e=>{"use strict";e.exports=require("@prisma/client")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},79941:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>x,routeModule:()=>c,serverHooks:()=>h,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>g});var a={};r.r(a),r.d(a,{GET:()=>p});var s=r(42706),o=r(28203),n=r(45994),i=r(96330),d=r(39187);let u=new i.PrismaClient;async function p(e){try{let e=new Date;e.setHours(0,0,0,0);let t=await u.order.aggregate({_sum:{totalPrice:!0},where:{createdAt:{gte:e},orderStatus:"DONE"}}),r=new Date,a=new Date(r.getFullYear(),r.getMonth(),1),s=await u.order.aggregate({_sum:{totalPrice:!0},where:{createdAt:{gte:a},orderStatus:"DONE"}}),o=await u.$queryRawUnsafe(`
      SELECT 
        DATE(created_at) as date,
        SUM(totalPrice) as total
      FROM 
        orders
      WHERE 
        created_at >= ? 
        AND order_status = 'DONE'
      GROUP BY 
        DATE(created_at)
      ORDER BY 
        DATE(created_at) ASC
    `,a),n=o.map(e=>new Date(e.date).toLocaleDateString("id-ID")),i=o.map(e=>parseFloat((e.total||0).toString()));return d.NextResponse.json({data:{todaySales:t._sum.totalPrice||0,thisMonthSales:s._sum.totalPrice||0,dailySales:{labels:n,data:i}}})}catch(e){return console.error("Error fetching sales data:",e),d.NextResponse.json({message:"Internal Server Error"},{status:500})}}let c=new s.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/authenticated/report/dashboard/route",pathname:"/api/authenticated/report/dashboard",filename:"route",bundlePath:"app/api/authenticated/report/dashboard/route"},resolvedPagePath:"D:\\Codings\\Freelance\\pos-sambel-ceurik-ngagoak\\src\\app\\api\\authenticated\\report\\dashboard\\route.ts",nextConfigOutput:"",userland:a}),{workAsyncStorage:l,workUnitAsyncStorage:g,serverHooks:h}=c;function x(){return(0,n.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:g})}},96487:()=>{},78335:()=>{}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[5994,5452],()=>r(79941));module.exports=a})();